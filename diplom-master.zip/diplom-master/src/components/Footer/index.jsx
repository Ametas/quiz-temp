import { Footer } from './ui/Footer.jsx'

export { Footer }