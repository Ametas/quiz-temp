import { Quiz } from './ui/Quiz.jsx'

export { Quiz }