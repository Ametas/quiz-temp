import { MainPage } from './ui/MainPage.jsx'

export { MainPage }