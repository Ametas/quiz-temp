export const data = [
  [
    {
      question: "Первый билет",
      option1: "дада",
      option2: "нет",
      option3: "мб",
      option4: "хз",
      answer: 1
    },
    {
      question: "Which device is required for the Internet connection?",
      option1: "да",
      option2: "нет",
      option3: "мб",
      option4: "хз",
      answer: 4
    },
  ],
  [
    {
      question: "Второй билет",
      option1: "дада",
      option2: "нет",
      option3: "мб",
      option4: "хз",
      answer: 1
    },
    {
      question: "Which device is required for the Internet connection?",
      option1: "да",
      option2: "нет",
      option3: "мб",
      option4: "хз",
      answer: 4
    },
  ]
]